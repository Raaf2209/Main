import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import javax.imageio.*;
import java.io.*;

public class Enemy {
	private boolean[][] alive = new boolean[5][6];
	private int xa = 1;
	private Main m;
	private int a, b, col, row;
	private BufferedImage img = null;
	private static final int DIAMETER = 45;

	public Enemy(int a, int b, Main m, int col, int row) {
		this.a = a;
		this.b = b;
		this.m = m;
		this.col = col;
		this.row = row;
		try {
			img = ImageIO.read(new File("C:\\\\Users\\\\s300041935\\\\eclipse-workspace\\\\RealProject\\\\src\\\\Enemy.png"));
		} catch (IOException e) {
			System.out.println("No Image");
		}
	}
	
	void move() {
		
		if ((a + xa < 0) || (a + xa > m.getWidth() - DIAMETER))
			xa *= -1;
		a = a + xa;
	}
	public int getY() {
		return this.b;
	}
	public int getX() {
		return this.a;
	}
	public int getRow() {
		return this.row;
	}
	public int getCol() {
		return this.col;
	}
	public void paint(Graphics g) {
		Graphics g2d = g;
		if (alive[col][row] = true) 
		g.drawImage(img, a, b, null);
		
	}

}
