import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import javax.imageio.*;
import java.io.*;

public class Spaceship {
    private int x, y, xa, ya;
    private boolean alive = true;
    private BufferedImage spaceship, spaceshipExhaust, spaceshipBack, spaceshipLeft, spaceshipRight = null;    

    private boolean right = false, left = false, up = false, down = false,space = false;
    private int counter = 1;
	private static final int DIAMETER = 50;

    public Spaceship(int x, int y, int xa, int ya) {
        try {
            spaceship = ImageIO.read(new File("C:\\Users\\s300041935\\eclipse-workspace\\RealProject\\src\\SpaceshipDefault.png"));
            spaceshipExhaust = ImageIO.read(new File("C:\\Users\\s300041935\\eclipse-workspace\\RealProject\\src\\SpaceshipExhaust.png"));
            spaceshipBack = ImageIO.read(new File("C:\\Users\\s300041935\\eclipse-workspace\\RealProject\\src\\SpaceshipBack.png"));
            spaceshipLeft = ImageIO.read(new File("C:\\Users\\s300041935\\eclipse-workspace\\RealProject\\src\\SpaceshipLeft.png"));
            spaceshipRight = ImageIO.read(new File("C:\\Users\\s300041935\\eclipse-workspace\\RealProject\\src\\SpaceshipRight.png"));
        } catch (IOException e) {
            System.out.println("No Image");
        }

        this.x = x;
        this.y = y;
        this.xa = xa;
        this.ya = ya;
    }

    public void keyPressed(KeyEvent e){
        if (e.getKeyCode() == KeyEvent.VK_LEFT) {
            left = true;
        }
        if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
            right = true;
        }
        if (e.getKeyCode() == KeyEvent.VK_UP) {
            up = true;
        }
        if (e.getKeyCode() == KeyEvent.VK_DOWN) {
            down = true;
        }
        if (e.getKeyCode() == KeyEvent.VK_SPACE) {
            space = true;
        }
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public boolean getSpace() {
        return space;
    }

    public boolean getUp() {
        return up;
    }
    public boolean getDown() {
        return down;
    }
    public boolean getLeft() {
        return left;
    }
    public boolean getRight() {
        return right;
    }
    
    public void keyReleased(KeyEvent e) {
        // When the key is released, set the Boolean to false, and change
        // acceleration to 0
        if (e.getKeyCode() == KeyEvent.VK_LEFT) {
            left = false;
            xa = 0;
        }
        if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
            right = false;
            xa = 0;
        }
        if (e.getKeyCode() == KeyEvent.VK_UP) {
            up = false;
            ya = 0;
        }
        if (e.getKeyCode() == KeyEvent.VK_DOWN) {
            down = false;
            ya = 0;
        }
        if (e.getKeyCode() == KeyEvent.VK_SPACE) {
            space = false;
            alive = true;
        }
    }

    public void move() {
        if (right) {
            xa = 3;
        }
        if (left) {
            xa = -3;
        }
        if (down) {
            ya = 3;
        }
        if (up) {
            ya = -3;
        }
        x += xa;
        y += ya;
        
		//Check if spaceship hits border
		if (x > 1230) x = -150;
		else if (x < -150) x = 1230;
		else if (y > 670) y = -150;
		else if (y < -150) y = 670;
    }
	public void collision(Bullets c) {
		if (c.getX() >= x && c.getX() <= x + 50 && c.getY() >= y && c.getY() <= y + 50 )
		{
			alive = false;
		}

	}
	public void collide(Asteroid a) {
		 int dx = (x-a.getX()) + (xa-a.getXA());
		 int dy = (y-a.getY()) + (ya-a.getYA());
		 if (Math.sqrt(dx*dx+dy*dy)<=DIAMETER) {
			alive = false;
		}
	}

    public void paint(Graphics2D g) {
        //If spaceship is moving forward add exhaust trail
    	if (alive == true)
    	{
        if (getUp() == true) {
            g.drawImage(spaceshipExhaust, getX(), getY(), null);
        }
        else if (getDown() == true) {
            g.drawImage(spaceshipBack, getX(), getY(), null);       	
        }
        else if (getLeft() == true) {
            g.drawImage(spaceshipLeft, getX(), getY(), null);       	
        }
        else if (getRight() == true) {
            g.drawImage(spaceshipRight, getX(), getY(), null);       	
        }
        else {
            g.drawImage(spaceship, getX(), getY(), null);
        }
        
        if (getSpace() == true) {
            g.setColor(new Color(255, 0, 0, 225)); 
        	if (counter == -1) {
                counter = counter*-1;
                g.fillRoundRect(getX()+65, getY()+40, 10, 40, 5, 10);
        	}
        	else if (counter == 1) {
                counter = counter*-1;
        		g.fillRoundRect(getX()+75+50, getY()+40, 10, 40, 5, 10);    
        	}
        }
        }
    }
}
